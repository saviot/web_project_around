1. Nama proyek: Tugas Sprint 5 Savio
2. Deskripsi proyek dan fungsinya: Proyek tugas triple ten sprint ke 5 yang berfungsi dalam membuat profile user website
3. Deskripsi teknologi dan teknik yang digunakan: menggunakan teknologi vscode dengan teknik js html css
4. Tautan menuju GitHub Pages: 
